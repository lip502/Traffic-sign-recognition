function s=kafang(v1,v2)
%v1,v2 should be the same size
[sizey1,sizex1]=size(v1);
[sizey2,sizex2]=size(v2);
if sizey1~=sizey2||sizex1~=sizex2
    error('v1,v2 is not the same size');
end
su=(v1-v2).^2;
sd=(v1+v2);
num=(find(sd~=0));
su=su(num);
sd=sd(num);
s=su./sd;
s=sum(s);
end