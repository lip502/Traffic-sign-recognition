%  LBP returns the local binary pattern image or LBP histogram of an image.
%  J = LBP(I) returns either a local binary pattern
%  coded image or the local binary pattern histogram of an intensity
%  image I. The LBP codes are computed using 8 sampling points on a
%  circle of radius 1.
%  J = LBP(I) returns the original (basic) LBP histogram of image I
%
%  Examples
%  --------
%       I=imread('rice.png');
%       H1=LBP(I);


function result = blalbp(I)
%I should be gray and the size of I is 64*64
% Check the type and size of I.
[ysize,xsize] = size(I);
%if isgray(I)==0&&isbw(I)==0
%   error('the image is in wrong form ');
%end
%if ysize~=64||xsize~=64
%  error('the image is in wrong form ');
%end
I=double(I);
spoints=[0 -1;-1 -1; -1 0; -1 1;0 1;1 1;1 0;1 -1];
pn=8;
r=1;
ylb=2;
yub=ysize-1;
xlb=2;
xub=xsize-1;
lbpn=256;        %lbpn=2^8
slbp=zeros(1,pn);
N_LBP=zeros(1,59);
num=0;
unilbp=zeros(58,1);
%--------------�����еľ���LBP------------
for i=0:255
    a=zeros(1,8);
    j=i;
    n=1;
    while j>=2
        m=fix(j/2);
        a(n)=j-m*2;
        j=m;
        n=n+1;
    end
    a(n)=j;
    re=unicode(a);
    if  re
        num=num+1;
        unilbp(num)=i;
    end
end

for i=ylb:yub
    for j=xlb:xub
        spoints(:,1)=spoints(:,1)+i;
        spoints(:,2)=spoints(:,2)+j;
        for p=1:pn
            slbp(p)=I(spoints(p,1),spoints(p,2));
            code_lbp=slbp>I(i,j);
        end
        LBP=128*code_lbp(8)+code_lbp(7)+32*code_lbp(6)+16*code_lbp(5)+...
            8*code_lbp(4)+4*code_lbp(3)+2*code_lbp(2)+code_lbp(1);
        index=find(unilbp==LBP);
        if isempty(index)
            N_LBP(59)=N_LBP(59)+1; %���Ǿ���LBP�Ĺ�Ϊһ��
        else
            N_LBP(index)=N_LBP(index)+1;
        end
        spoints=[0 -1;-1 -1; -1 0; -1 1;0 1;1 1;1 0;1 -1];
    end
end
result=N_LBP;
end


