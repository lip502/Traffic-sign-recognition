function isuniform=unicode(point_lbp)

upti=0;

for i=1:7
    if point_lbp(i)~=point_lbp(i+1)
        upti=upti+1;
    end
end
if upti>2
    isuniform=false;
else
    isuniform=true;
end
end