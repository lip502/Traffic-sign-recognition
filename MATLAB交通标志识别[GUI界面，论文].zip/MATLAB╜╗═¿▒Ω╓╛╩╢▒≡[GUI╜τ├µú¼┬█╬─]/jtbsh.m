function varargout = jtbsh(varargin)
% JTBSH MATLAB code for jtbsh.fig
%      JTBSH, by itself, creates a new JTBSH or raises the existing
%      singleton*.
%
%      H = JTBSH returns the handle to a new JTBSH or the handle to
%      the existing singleton*.
%
%      JTBSH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in JTBSH.M with the given input arguments.
%
%      JTBSH('Property','Value',...) creates a new JTBSH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before jtbsh_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to jtbsh_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help jtbsh

% Last Modified by GUIDE v2.5 25-May-2021 22:02:43

% Begin initialization code - DO NOT EDIT 
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @jtbsh_OpeningFcn, ...
                   'gui_OutputFcn',  @jtbsh_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before jtbsh is made visible.
function jtbsh_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to jtbsh (see VARARGIN)

% Choose default command line output for jtbsh
handles.output = hObject;



% Update handles structure
guidata(hObject, handles);

% UIWAIT makes jtbsh wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = jtbsh_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btlc.
function btlc_Callback(hObject, eventdata, handles)
% hObject    handle to btlc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global lb;
global shape;
global cor;
global img;
global new3;
global I1;
global new4;
I=img;
%%%RBG��ɫ�ָ�
[m,n,k]=size(I);
I1=rgb2gray(I);
 r=I(:,:,1);
 g=I(:,:,2);
 b=I(:,:,3);
new=zeros(m,n);
for i=1:m
    for j=1:n
        if r(i,j)-g(i,j)> 50 && r(i,j)-b(i,j)>100
        new(i,j)=255; 
        cor='��ɫ';
       else if  r(i,j)-b(i,j)> 50 && g(i,j)-b(i,j)>100
         new(i,j)=255;       
         cor='��ɫ';
            end
        end
    end
end 

new1=bwareaopen(new,500);%ȥ��С��������
new2=edge(new1,'canny');%��ȡ�߽�
new3=bwfill(new2,'holes');%����ڲ�����
new4=edge(new3,'canny');%�ٴ���ȡ�߽�
%%%%%%%%Hu��������ж���״%%%%%%%%%%%
fai1=two_dim_moment(new4);
%��ȡ3,4,5��Ϊ��������
hf=zeros(1,3);
hf(1)=fai1(3);
hf(2)=fai1(4);
hf(3)=fai1(5);
hfc=[0.0231,0.0368,0.0011];
hftr=[719.7338,7.2864,-527.661];
if norm(hf-hfc)<5
    shape='Բ��';
else if norm(hf-hftr)<5
        shape='������';
    end
end

[ms,ns]=find(new4==1);
up=min(ms)-5;
dn=max(ms)+5;
lf=min(ns)-5;
rg=max(ns)+5;

axes(handles.axout);
axis on;
imshow(img);
axis equal;
str1=sprintf('����˼·\n\n');
str2=sprintf('    רעMATLAB��δ�����֣���Q�ң�115195686 \n');
string=[str1 str2];
msgbox(string,'��ܰ��ʾ','none');
return

    
    


% --- Executes on button press in btiden.
function btiden_Callback(hObject, eventdata, handles)
% hObject    handle to btiden (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

str={'QQ: 115195686'};
set(handles.txtout,'string',str);


% --- Executes on button press in btread.
function btread_Callback(hObject, eventdata, handles)
% hObject    handle to btread (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sdlb;
global img;
%������������������������������ͼ�񡪡�������������������������
[filename, pathname] = uigetfile( ...
{'*.bmp;*.jpg;*.png;*.jpeg', 'Image Files (*.bmp,*.jpg,*.png,*.jpeg)'; ...
'*.*', 'All Files (*.*)'}, ...
'Pick an image');
if isequal(filename,0)||isequal(pathname,0)
    return;
end;
fpath=[pathname filename];
img=imread(fpath);
axes(handles.axin)
axis on;
imshow(img);
axis equal;
